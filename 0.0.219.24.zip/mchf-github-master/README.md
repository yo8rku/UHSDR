<H3>This is the GitHub Repo related to firmware and bootloader for SDR-QRP-transceiver mcHF.</H3><br>
<br>
Explanation of different branches:<br>
<br>
<b>master</b>: latest STABLE version<br>
<b>testing</b>: latest upcoming version in testing stage, containing changes from actual work of every developer<br>
<b>devel-ABCDEF-0.0.xxx.yyy.z</b>: devel version of specific developer.<br>
<br>
Master and testing include binaries to use for end-users. It is recommended only to use these two branches as end-user!<br>
<br>
All other branches may or may not include binaries. Use is "for your own risk". Code maybe non-functional or instable.<br>
<br>
If you want to take part in development use testing-branch as base for creating your own branch named as "devel-ABCDEF...." above. Testing branch is the most up-to-date branch containing pre-release versions of the work of the whole community.<br>
<br>
vy 73 de<br>
DF8OE