mcHF firmware and bootloader - sources and binaries


In master and testing branch you can find binaries for direct use.

Binaries are located in mchf-eclipse and are named:
- bootloader??.dfu
- mchf_binary_for_flash??.bin

?? differs in branch.

If you only want binaries and not complete sources click on file you want to download and then on the button "Raw" right above the grey bar.

Have fun - Open-Source opens possibilities!

KA7OEI, Clint

DF8OE, Andreas
