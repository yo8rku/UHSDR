Stable branch of mcHF firmware and bootloader - sources and binaries


Version <219.27.0>


Binaries are located in mchf-eclipse and are named:
- bootloader.dfu
- mchf_binary_for_flash.bin

If you only want binaries and not complete sources click on file you want to download and then on the button "Raw" right above the grey bar.

Have fun - Open-Source opens possibilities!

M0NKA, Chris<br>
KA7OEI, Clint<br>
DF8OE, Andreas
