mcHF firmware with configuration files for use with Eclipse, CoIDE and makefile for use on console (stable branch). Recommended firmware. Binary for flashing in root directory.
