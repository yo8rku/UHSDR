This project is the porting of cctbcn's CooCox firmware for mcHF
to Eclipse. Now both IDEs can work on the same sources.


I*M*P*O*R*T*A*N*T I*N*F*O*R*M*A*T*I*O*N

If you work using CooCox and add a new subfolder which contains header-files (.h),
please name them in history.txt. Otherwise you break Eclipse users because Eclipse
MUST know explicit each path of header-files. With your information Eclipse
configuration can be updated uncomplicated.

Have fun!

vy 73 de
Andreas, DF8OE