libm.a is only used by CoIDE and Eclipse. Makefile uses libm.a
which is included in toolchain.

DF8OE, Andreas